package app.sockspass;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.HostKey;
import com.jcraft.jsch.HostKeyRepository;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.UserInfo;

import java.io.Closeable;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Equivalent of "ssh -D": logs into an SSH server with a private key and exposes a
 * local SOCKS5 server (127.0.0.1, no auth) whose CONNECT requests are carried as
 * SSH direct-tcpip channels. Reconnects the SSH session on demand if it drops.
 */
final class SshTunnel implements Closeable {

    static final class HostKeyMismatchException extends Exception {
        HostKeyMismatchException(String fingerprint) {
            super("SSH host key changed! Server now presents " + fingerprint
                    + ". If you expected this, tap \"Forget host key\" and start again.");
        }
    }

    private final JSch jsch = new JSch();
    private final String host, user;
    private final int port;
    private final String pinnedKey; // base64 of the trusted host key, or null for trust-on-first-use

    private volatile String seenKey;
    private volatile String seenFingerprint;
    private volatile String mismatchFingerprint;

    private volatile Session session;
    private volatile boolean closed;
    private ServerSocket server;
    private final ExecutorService pool = Executors.newCachedThreadPool();

    SshTunnel(String host, int port, String user, String privateKey, String passphrase, String pinnedKey)
            throws JSchException {
        this.host = host;
        this.port = port;
        this.user = user;
        this.pinnedKey = (pinnedKey == null || pinnedKey.isEmpty()) ? null : pinnedKey;
        byte[] pass = (passphrase == null || passphrase.isEmpty())
                ? null : passphrase.getBytes(StandardCharsets.UTF_8);
        jsch.addIdentity("key", privateKey.trim().concat("\n").getBytes(StandardCharsets.UTF_8), null, pass);
        jsch.setHostKeyRepository(new PinnedHostKeys());
    }

    /** Connects to the SSH server and starts the local SOCKS5 listener. Returns its port. */
    int start() throws Exception {
        connect();
        server = new ServerSocket(0, 64, InetAddress.getByName("127.0.0.1"));
        pool.execute(this::acceptLoop);
        return server.getLocalPort();
    }

    /** Base64 host key accepted on this connection (to pin on first use). */
    String hostKey() { return seenKey; }

    String fingerprint() { return seenFingerprint; }

    private synchronized Session connect() throws Exception {
        Session s = session;
        if (s != null && s.isConnected()) return s;
        if (closed) throw new IOException("Tunnel closed");

        s = jsch.getSession(user, host, port);
        s.setConfig("StrictHostKeyChecking", "yes");
        s.setConfig("PreferredAuthentications", "publickey");
        s.setServerAliveInterval(20_000);
        s.setServerAliveCountMax(3);
        try {
            s.connect(15_000);
        } catch (JSchException e) {
            if (mismatchFingerprint != null) throw new HostKeyMismatchException(mismatchFingerprint);
            throw friendly(e);
        }
        session = s;
        return s;
    }

    private static Exception friendly(JSchException e) {
        String m = String.valueOf(e.getMessage());
        if (m.contains("Auth fail") || m.contains("Auth cancel")) {
            return new IOException("SSH login failed: the server rejected the key for this user");
        }
        if (m.contains("invalid privatekey") || m.contains("decrypt")) {
            return new IOException("Couldn't read the private key (unsupported format or wrong passphrase)");
        }
        if (m.contains("timeout") || m.contains("timed out")) {
            return new IOException("SSH server not reachable (timeout)");
        }
        return new IOException("SSH: " + m, e);
    }

    private void acceptLoop() {
        while (!closed) {
            Socket c;
            try {
                c = server.accept();
            } catch (IOException e) {
                break;
            }
            pool.execute(() -> handle(c));
        }
    }

    private void handle(Socket client) {
        Channel ch = null;
        try {
            client.setTcpNoDelay(true);
            DataInputStream in = new DataInputStream(client.getInputStream());
            OutputStream out = client.getOutputStream();

            // Greeting: VER NMETHODS METHODS... -> reply "no authentication"
            if (in.readUnsignedByte() != 5) return;
            in.readFully(new byte[in.readUnsignedByte()]);
            out.write(new byte[]{5, 0});
            out.flush();

            // Request: VER CMD RSV ATYP DST.ADDR DST.PORT
            in.readUnsignedByte();
            int cmd = in.readUnsignedByte();
            in.readUnsignedByte();
            int atyp = in.readUnsignedByte();
            String dst;
            if (atyp == 1) {
                byte[] a = new byte[4];
                in.readFully(a);
                dst = InetAddress.getByAddress(a).getHostAddress();
            } else if (atyp == 3) {
                byte[] a = new byte[in.readUnsignedByte()];
                in.readFully(a);
                dst = new String(a, StandardCharsets.US_ASCII);
            } else if (atyp == 4) {
                byte[] a = new byte[16];
                in.readFully(a);
                dst = InetAddress.getByAddress(a).getHostAddress();
            } else {
                reply(out, 8); // address type not supported
                return;
            }
            int dstPort = in.readUnsignedShort();

            if (cmd != 1) {
                reply(out, 7); // only CONNECT; SSH cannot carry UDP
                return;
            }

            InputStream rin;
            OutputStream rout;
            try {
                ch = connect().getStreamForwarder(dst, dstPort);
                rin = ch.getInputStream();
                rout = ch.getOutputStream();
                ch.connect(10_000);
            } catch (Exception e) {
                reply(out, 5); // connection refused
                return;
            }
            reply(out, 0);

            final Channel channel = ch;
            pool.execute(() -> {
                pump(in, rout);
                channel.disconnect();
                closeQuietly(client);
            });
            pump(rin, out);
        } catch (IOException ignored) {
            // client went away
        } finally {
            if (ch != null) ch.disconnect();
            closeQuietly(client);
        }
    }

    private static void reply(OutputStream out, int code) throws IOException {
        out.write(new byte[]{5, (byte) code, 0, 1, 0, 0, 0, 0, 0, 0});
        out.flush();
    }

    private static void pump(InputStream from, OutputStream to) {
        byte[] buf = new byte[16 * 1024];
        try {
            int n;
            while ((n = from.read(buf)) >= 0) {
                to.write(buf, 0, n);
                to.flush();
            }
        } catch (IOException ignored) {
        }
    }

    private static void closeQuietly(Closeable c) {
        try {
            c.close();
        } catch (IOException ignored) {
        }
    }

    @Override
    public void close() {
        closed = true;
        if (server != null) closeQuietly(server);
        Session s = session;
        if (s != null) s.disconnect();
        pool.shutdownNow();
    }

    static String fingerprintOf(byte[] key) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(key);
            return "SHA256:" + Base64.getEncoder().withoutPadding().encodeToString(d);
        } catch (Exception e) {
            return "?";
        }
    }

    /** Trust-on-first-use: accepts any key when nothing is pinned, otherwise only the pinned one. */
    private final class PinnedHostKeys implements HostKeyRepository {
        @Override
        public int check(String h, byte[] key) {
            String b64 = Base64.getEncoder().encodeToString(key);
            if (pinnedKey == null || pinnedKey.equals(b64)) {
                seenKey = b64;
                seenFingerprint = fingerprintOf(key);
                mismatchFingerprint = null;
                return OK;
            }
            mismatchFingerprint = fingerprintOf(key);
            return CHANGED;
        }

        @Override public void add(HostKey hostkey, UserInfo ui) { }
        @Override public void remove(String h, String type) { }
        @Override public void remove(String h, String type, byte[] key) { }
        @Override public String getKnownHostsRepositoryID() { return "SocksPass"; }
        @Override public HostKey[] getHostKey() { return new HostKey[0]; }
        @Override public HostKey[] getHostKey(String h, String type) { return new HostKey[0]; }
    }
}
