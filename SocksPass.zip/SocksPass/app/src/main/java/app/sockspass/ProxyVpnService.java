package app.sockspass;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import hev.htproxy.TProxyService;

public class ProxyVpnService extends VpnService {
    public static final String ACTION_START = "app.sockspass.START";
    public static final String ACTION_STOP = "app.sockspass.STOP";

    private static final int MTU = 8500;
    private static final String TUN_IPV4 = "198.18.0.1";
    private static final String TUN_IPV6 = "fc00::1";
    private static final String MAPPED_DNS = "198.18.0.2";

    private static volatile boolean running;
    private static volatile String lastError;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private ParcelFileDescriptor tun;
    private SshTunnel ssh;

    static boolean isRunning() { return running; }
    static String lastError() { return lastError; }

    /** Returns [txBytes, rxBytes] or null. */
    static long[] stats() {
        if (!running) return null;
        try {
            long[] s = TProxyService.TProxyGetStats();
            return (s != null && s.length >= 4) ? new long[]{s[1], s[3]} : null;
        } catch (Throwable t) {
            return null;
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_STOP.equals(action)) {
            worker.execute(this::stopTunnel);
        } else {
            worker.execute(this::startTunnel);
        }
        return START_NOT_STICKY;
    }

    private void startTunnel() {
        if (running) return;
        lastError = null;
        Prefs p = new Prefs(this);
        try {
            if (p.apps().isEmpty()) throw new IllegalStateException("No apps selected");

            String socksIp;
            int socksPort;
            boolean remoteDns;
            if (p.sshMode()) {
                // SSH mode: connect first (clear errors before the VPN goes up), then point the
                // tunnel engine at the local SOCKS5 bridge. SSH carries TCP only, so DNS must be
                // resolved on the server side.
                ssh = new SshTunnel(p.sshHost(), p.sshPort(), p.sshUser(), p.sshKey(),
                        p.sshPassphrase(), p.sshHostKey());
                socksPort = ssh.start();
                socksIp = "127.0.0.1";
                remoteDns = true;
                if (p.sshHostKey().isEmpty() && ssh.hostKey() != null) {
                    p.pinHostKey(ssh.hostKey(), ssh.fingerprint());
                }
            } else {
                // Resolve the proxy host here: the native engine expects an IP address.
                // This app is not routed through the tunnel, so the lookup goes out directly.
                socksIp = InetAddress.getByName(p.host()).getHostAddress();
                socksPort = p.port();
                remoteDns = p.remoteDns();
            }

            Builder b = new Builder()
                    .setSession("SocksPass → " + p.endpoint())
                    .setMtu(MTU)
                    .setBlocking(false)
                    .addAddress(TUN_IPV4, 32)
                    .addRoute("0.0.0.0", 0)
                    .addAddress(TUN_IPV6, 128)
                    .addRoute("::", 0)
                    .addDnsServer(remoteDns ? MAPPED_DNS : "1.1.1.1");

            int added = 0;
            for (String pkg : p.apps()) {
                try {
                    b.addAllowedApplication(pkg);
                    added++;
                } catch (PackageManager.NameNotFoundException ignored) {
                    // App was uninstalled since it was selected.
                }
            }
            if (added == 0) throw new IllegalStateException("None of the selected apps are installed");

            b.setConfigureIntent(PendingIntent.getActivity(this, 0,
                    new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE));

            tun = b.establish();
            if (tun == null) throw new IllegalStateException("VPN permission not granted");

            File cfg = new File(getCacheDir(), "tunnel.yml");
            try (FileOutputStream out = new FileOutputStream(cfg, false)) {
                out.write(buildConfig(p, socksIp, socksPort, remoteDns).getBytes(StandardCharsets.UTF_8));
            }

            if (!TProxyService.TProxyStartService(cfg.getAbsolutePath(), tun.getFd())) {
                throw new IllegalStateException("Tunnel engine failed to start");
            }
            running = true;
        } catch (Throwable t) {
            lastError = t.getMessage() != null ? t.getMessage() : t.toString();
            closeTun();
            closeSsh();
            stopSelf();
        }
    }

    private void closeSsh() {
        if (ssh != null) {
            ssh.close();
            ssh = null;
        }
    }

    private void stopTunnel() {
        if (running) {
            try {
                TProxyService.TProxyStopService();
            } catch (Throwable ignored) {
            }
        }
        running = false;
        closeTun();
        closeSsh();
        stopSelf();
    }

    private void closeTun() {
        if (tun != null) {
            try {
                tun.close();
            } catch (IOException ignored) {
            }
            tun = null;
        }
    }

    private static String q(String s) {
        return "'" + s.replace("'", "''") + "'";
    }

    private static String buildConfig(Prefs p, String socksIp, int socksPort, boolean remoteDns) {
        StringBuilder sb = new StringBuilder();
        sb.append("tunnel:\n");
        sb.append("  mtu: ").append(MTU).append('\n');
        sb.append("socks5:\n");
        sb.append("  port: ").append(socksPort).append('\n');
        sb.append("  address: ").append(q(socksIp)).append('\n');
        sb.append("  udp: 'udp'\n");
        if (!p.sshMode() && p.auth()) {
            sb.append("  username: ").append(q(p.user())).append('\n');
            sb.append("  password: ").append(q(p.pass())).append('\n');
        }
        if (remoteDns) {
            // Answers DNS with fake IPs and sends the real hostname to the proxy,
            // so name resolution happens on the proxy side (no UDP needed).
            sb.append("mapdns:\n");
            sb.append("  address: ").append(MAPPED_DNS).append('\n');
            sb.append("  port: 53\n");
            sb.append("  network: 100.64.0.0\n");
            sb.append("  netmask: 255.192.0.0\n");
            sb.append("  cache-size: 10000\n");
        }
        return sb.toString();
    }

    @Override
    public void onRevoke() {
        // Another VPN took over or the user disconnected from system settings.
        worker.execute(this::stopTunnel);
    }

    @Override
    public void onDestroy() {
        if (running) {
            try {
                TProxyService.TProxyStopService();
            } catch (Throwable ignored) {
            }
            running = false;
        }
        closeTun();
        closeSsh();
        worker.shutdown();
        super.onDestroy();
    }
}
