package app.sockspass;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.format.Formatter;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_VPN = 1;
    private static final int REQ_KEY = 2;

    private Prefs prefs;
    private RadioButton modeSocks, modeSsh;
    private View socksSection, sshSection, authFields;
    private EditText host, port, user, pass;
    private EditText sshHost, sshPort, sshUser, sshPassphrase;
    private Switch auth, remoteDns;
    private Button appsButton, toggle, keyImport, keyPaste, keyClear, forgetHostKey;
    private TextView status, keyStatus, hostKey;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            refresh();
            ui.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = new Prefs(this);

        modeSocks = findViewById(R.id.mode_socks);
        modeSsh = findViewById(R.id.mode_ssh);
        socksSection = findViewById(R.id.socks_section);
        sshSection = findViewById(R.id.ssh_section);
        host = findViewById(R.id.host);
        port = findViewById(R.id.port);
        user = findViewById(R.id.user);
        pass = findViewById(R.id.pass);
        auth = findViewById(R.id.auth);
        authFields = findViewById(R.id.auth_fields);
        sshHost = findViewById(R.id.ssh_host);
        sshPort = findViewById(R.id.ssh_port);
        sshUser = findViewById(R.id.ssh_user);
        sshPassphrase = findViewById(R.id.ssh_passphrase);
        keyStatus = findViewById(R.id.key_status);
        keyImport = findViewById(R.id.key_import);
        keyPaste = findViewById(R.id.key_paste);
        keyClear = findViewById(R.id.key_clear);
        hostKey = findViewById(R.id.host_key);
        forgetHostKey = findViewById(R.id.forget_host_key);
        remoteDns = findViewById(R.id.remote_dns);
        appsButton = findViewById(R.id.apps);
        toggle = findViewById(R.id.toggle);
        status = findViewById(R.id.status);

        host.setText(prefs.host());
        port.setText(String.valueOf(prefs.port()));
        auth.setChecked(prefs.auth());
        user.setText(prefs.user());
        pass.setText(prefs.pass());
        remoteDns.setChecked(prefs.remoteDns());
        sshHost.setText(prefs.sshHost());
        sshPort.setText(String.valueOf(prefs.sshPort()));
        sshUser.setText(prefs.sshUser());
        sshPassphrase.setText(prefs.sshPassphrase());
        (prefs.sshMode() ? modeSsh : modeSocks).setChecked(true);

        auth.setOnCheckedChangeListener((b, on) -> updateVisibility());
        modeSocks.setOnCheckedChangeListener((b, on) -> updateVisibility());
        modeSsh.setOnCheckedChangeListener((b, on) -> updateVisibility());
        updateVisibility();
        updateKeyViews();

        keyImport.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("*/*");
            startActivityForResult(i, REQ_KEY);
        });
        keyPaste.setOnClickListener(v -> {
            ClipboardManager cm = getSystemService(ClipboardManager.class);
            ClipData clip = cm != null ? cm.getPrimaryClip() : null;
            CharSequence text = (clip != null && clip.getItemCount() > 0)
                    ? clip.getItemAt(0).coerceToText(this) : null;
            setKey(text == null ? "" : text.toString());
        });
        keyClear.setOnClickListener(v -> {
            prefs.setSshKey("");
            updateKeyViews();
        });
        forgetHostKey.setOnClickListener(v -> {
            prefs.forgetHostKey();
            updateKeyViews();
            toast("Host key forgotten; the next connection will be trusted");
        });

        appsButton.setOnClickListener(v -> {
            saveForm(false);
            startActivity(new Intent(this, AppPickerActivity.class));
        });

        toggle.setOnClickListener(v -> {
            if (ProxyVpnService.isRunning()) {
                startService(new Intent(this, ProxyVpnService.class).setAction(ProxyVpnService.ACTION_STOP));
                return;
            }
            if (!saveForm(true)) return;
            if (prefs.apps().isEmpty()) {
                toast("Pick at least one app first");
                return;
            }
            Intent consent = VpnService.prepare(this);
            if (consent != null) {
                startActivityForResult(consent, REQ_VPN);
            } else {
                onActivityResult(REQ_VPN, RESULT_OK, null);
            }
        });
    }

    private void updateVisibility() {
        boolean ssh = modeSsh.isChecked();
        socksSection.setVisibility(ssh ? View.GONE : View.VISIBLE);
        sshSection.setVisibility(ssh ? View.VISIBLE : View.GONE);
        authFields.setVisibility(auth.isChecked() ? View.VISIBLE : View.GONE);
        // SSH only carries TCP, so DNS always has to be resolved on the server.
        remoteDns.setVisibility(ssh ? View.GONE : View.VISIBLE);
    }

    private void updateKeyViews() {
        String k = prefs.sshKey();
        keyStatus.setText(k.isEmpty() ? "Private key: none" : "Private key: " + describeKey(k));
        String fp = prefs.sshHostFingerprint();
        if (prefs.sshHostKey().isEmpty()) {
            hostKey.setText("Server host key: not pinned yet (trusted on first connection)");
            forgetHostKey.setVisibility(View.GONE);
        } else {
            hostKey.setText("Server host key pinned:\n" + fp);
            forgetHostKey.setVisibility(View.VISIBLE);
        }
    }

    private static String describeKey(String k) {
        if (k.contains("BEGIN OPENSSH PRIVATE KEY")) return "loaded (OpenSSH format)";
        if (k.contains("BEGIN RSA PRIVATE KEY")) return "loaded (RSA, PEM)";
        if (k.contains("BEGIN EC PRIVATE KEY")) return "loaded (ECDSA, PEM)";
        if (k.contains("BEGIN PRIVATE KEY") || k.contains("BEGIN ENCRYPTED PRIVATE KEY")) return "loaded (PKCS#8)";
        if (k.startsWith("PuTTY-User-Key-File")) return "loaded (PuTTY .ppk)";
        return "loaded";
    }

    private void setKey(String text) {
        String k = text.trim();
        boolean looksLikeKey = k.contains("PRIVATE KEY-----") || k.startsWith("PuTTY-User-Key-File");
        if (!looksLikeKey) {
            toast(k.contains("ssh-") && !k.contains("PRIVATE")
                    ? "That's a public key; the app needs the private key"
                    : "That doesn't look like a private key");
            return;
        }
        prefs.setSshKey(k);
        updateKeyViews();
        toast("Private key saved");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_VPN) {
            if (resultCode == RESULT_OK) {
                startService(new Intent(this, ProxyVpnService.class).setAction(ProxyVpnService.ACTION_START));
            } else {
                toast("VPN permission is required");
            }
        } else if (requestCode == REQ_KEY && resultCode == RESULT_OK && data != null && data.getData() != null) {
            setKey(readSmallFile(data.getData()));
        }
    }

    private String readSmallFile(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) return "";
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0 && bos.size() < 64 * 1024) bos.write(buf, 0, n);
            return bos.toString(StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            toast("Couldn't read the file");
            return "";
        }
    }

    private static int parsePort(EditText e) {
        try {
            int p = Integer.parseInt(e.getText().toString().trim());
            return (p >= 1 && p <= 65535) ? p : -1;
        } catch (NumberFormatException ex) {
            return -1;
        }
    }

    /** Saves the form. When strict, validates and reports problems. */
    private boolean saveForm(boolean strict) {
        boolean ssh = modeSsh.isChecked();
        prefs.setMode(ssh);

        String h = host.getText().toString().trim();
        int p = parsePort(port);
        prefs.saveServer(h, p > 0 ? p : 1080, auth.isChecked(),
                user.getText().toString(), pass.getText().toString(), remoteDns.isChecked());

        String sh = sshHost.getText().toString().trim();
        int sp = parsePort(sshPort);
        String su = sshUser.getText().toString().trim();
        prefs.saveSsh(sh, sp > 0 ? sp : 22, su, sshPassphrase.getText().toString());

        if (!strict) return true;
        if (ssh) {
            if (sh.isEmpty()) { toast("Enter the SSH host"); return false; }
            if (sp < 0) { toast("Enter a valid SSH port"); return false; }
            if (su.isEmpty()) { toast("Enter the SSH username"); return false; }
            if (prefs.sshKey().isEmpty()) { toast("Import or paste your private key"); return false; }
        } else {
            if (h.isEmpty()) { toast("Enter the proxy host"); return false; }
            if (p < 0) { toast("Enter a valid port (1–65535)"); return false; }
            if (auth.isChecked() && user.getText().toString().isEmpty()) {
                toast("Enter a username or turn off authentication");
                return false;
            }
        }
        return true;
    }

    private void refresh() {
        int n = prefs.apps().size();
        appsButton.setText("Choose apps (" + n + " selected)");

        boolean on = ProxyVpnService.isRunning();
        toggle.setText(on ? "Stop" : "Start");
        setFormEnabled(!on);
        updateKeyViews();

        if (on) {
            long[] s = ProxyVpnService.stats();
            String traffic = s == null ? "" : "\n↑ " + Formatter.formatShortFileSize(this, s[0])
                    + "   ↓ " + Formatter.formatShortFileSize(this, s[1]);
            status.setText("Connected — " + n + " app(s) via " + prefs.endpoint() + traffic);
        } else {
            String err = ProxyVpnService.lastError();
            status.setText(err == null ? "Stopped" : "Error: " + err);
        }
    }

    private void setFormEnabled(boolean enabled) {
        for (View v : new View[]{modeSocks, modeSsh, host, port, auth, user, pass, remoteDns,
                sshHost, sshPort, sshUser, sshPassphrase, keyImport, keyPaste, keyClear,
                forgetHostKey, appsButton}) {
            v.setEnabled(enabled);
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ui.post(tick);
    }

    @Override
    protected void onPause() {
        ui.removeCallbacks(tick);
        if (!ProxyVpnService.isRunning()) saveForm(false);
        super.onPause();
    }
}
