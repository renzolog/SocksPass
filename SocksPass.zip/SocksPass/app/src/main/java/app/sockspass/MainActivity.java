package app.sockspass;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.format.Formatter;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_VPN = 1;

    private Prefs prefs;
    private EditText host, port, user, pass;
    private Switch auth, remoteDns;
    private View authFields;
    private Button appsButton, toggle;
    private TextView status;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            refresh();
            ui.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = new Prefs(this);

        host = findViewById(R.id.host);
        port = findViewById(R.id.port);
        user = findViewById(R.id.user);
        pass = findViewById(R.id.pass);
        auth = findViewById(R.id.auth);
        remoteDns = findViewById(R.id.remote_dns);
        authFields = findViewById(R.id.auth_fields);
        appsButton = findViewById(R.id.apps);
        toggle = findViewById(R.id.toggle);
        status = findViewById(R.id.status);

        host.setText(prefs.host());
        port.setText(String.valueOf(prefs.port()));
        auth.setChecked(prefs.auth());
        user.setText(prefs.user());
        pass.setText(prefs.pass());
        remoteDns.setChecked(prefs.remoteDns());
        authFields.setVisibility(prefs.auth() ? View.VISIBLE : View.GONE);

        auth.setOnCheckedChangeListener((b, on) -> authFields.setVisibility(on ? View.VISIBLE : View.GONE));

        appsButton.setOnClickListener(v -> {
            saveForm(false);
            startActivity(new Intent(this, AppPickerActivity.class));
        });

        toggle.setOnClickListener(v -> {
            if (ProxyVpnService.isRunning()) {
                startService(new Intent(this, ProxyVpnService.class).setAction(ProxyVpnService.ACTION_STOP));
                return;
            }
            if (!saveForm(true)) return;
            if (prefs.apps().isEmpty()) {
                toast("Pick at least one app first");
                return;
            }
            Intent consent = VpnService.prepare(this);
            if (consent != null) {
                startActivityForResult(consent, REQ_VPN);
            } else {
                onActivityResult(REQ_VPN, RESULT_OK, null);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_VPN) {
            if (resultCode == RESULT_OK) {
                startService(new Intent(this, ProxyVpnService.class).setAction(ProxyVpnService.ACTION_START));
            } else {
                toast("VPN permission is required");
            }
        }
    }

    /** Saves the form. When strict, validates and reports problems. */
    private boolean saveForm(boolean strict) {
        String h = host.getText().toString().trim();
        int p;
        try {
            p = Integer.parseInt(port.getText().toString().trim());
        } catch (NumberFormatException e) {
            p = -1;
        }
        if (strict) {
            if (h.isEmpty()) { toast("Enter the proxy host"); return false; }
            if (p < 1 || p > 65535) { toast("Enter a valid port (1–65535)"); return false; }
            if (auth.isChecked() && user.getText().toString().isEmpty()) {
                toast("Enter a username or turn off authentication");
                return false;
            }
        }
        prefs.saveServer(h, (p >= 1 && p <= 65535) ? p : 1080, auth.isChecked(),
                user.getText().toString(), pass.getText().toString(), remoteDns.isChecked());
        return true;
    }

    private void refresh() {
        int n = prefs.apps().size();
        appsButton.setText("Choose apps (" + n + " selected)");

        boolean on = ProxyVpnService.isRunning();
        toggle.setText(on ? "Stop" : "Start");
        setFormEnabled(!on);

        if (on) {
            long[] s = ProxyVpnService.stats();
            String traffic = s == null ? "" : "\n↑ " + Formatter.formatShortFileSize(this, s[0])
                    + "   ↓ " + Formatter.formatShortFileSize(this, s[1]);
            status.setText("Connected — " + n + " app(s) via " + prefs.host() + ":" + prefs.port() + traffic);
        } else {
            String err = ProxyVpnService.lastError();
            status.setText(err == null ? "Stopped" : "Error: " + err);
        }
    }

    private void setFormEnabled(boolean enabled) {
        host.setEnabled(enabled);
        port.setEnabled(enabled);
        auth.setEnabled(enabled);
        user.setEnabled(enabled);
        pass.setEnabled(enabled);
        remoteDns.setEnabled(enabled);
        appsButton.setEnabled(enabled);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ui.post(tick);
    }

    @Override
    protected void onPause() {
        ui.removeCallbacks(tick);
        if (!ProxyVpnService.isRunning()) saveForm(false);
        super.onPause();
    }
}
