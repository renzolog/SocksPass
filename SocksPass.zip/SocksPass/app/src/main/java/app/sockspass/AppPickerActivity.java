package app.sockspass;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class AppPickerActivity extends Activity {
    private static final class AppItem {
        String pkg, label;
        Drawable icon;
        boolean launchable;
    }

    private Prefs prefs;
    private Set<String> selected;
    private final List<AppItem> all = new ArrayList<>();
    private final List<AppItem> shown = new ArrayList<>();
    private AppAdapter adapter;
    private EditText search;
    private CheckBox showAll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_picker);
        setTitle("Apps through proxy");
        prefs = new Prefs(this);
        selected = prefs.apps();

        search = findViewById(R.id.search);
        showAll = findViewById(R.id.show_all);
        ListView list = findViewById(R.id.list);
        ProgressBar progress = findViewById(R.id.progress);

        adapter = new AppAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            AppItem it = shown.get(position);
            if (!selected.remove(it.pkg)) selected.add(it.pkg);
            prefs.saveApps(selected);
            adapter.notifyDataSetChanged();
            updateTitle();
        });

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { applyFilter(); }
            public void afterTextChanged(Editable s) { }
        });
        showAll.setOnCheckedChangeListener((b, on) -> applyFilter());

        new Thread(() -> {
            List<AppItem> loaded = loadApps();
            runOnUiThread(() -> {
                all.clear();
                all.addAll(loaded);
                progress.setVisibility(View.GONE);
                applyFilter();
                updateTitle();
            });
        }).start();
    }

    private List<AppItem> loadApps() {
        PackageManager pm = getPackageManager();
        List<AppItem> out = new ArrayList<>();
        for (PackageInfo pi : pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)) {
            if (pi.packageName.equals(getPackageName())) continue;
            boolean internet = pi.requestedPermissions != null
                    && Arrays.asList(pi.requestedPermissions).contains("android.permission.INTERNET");
            if (!internet) continue;
            ApplicationInfo ai = pi.applicationInfo;
            if (ai == null) continue;
            AppItem it = new AppItem();
            it.pkg = pi.packageName;
            it.label = String.valueOf(ai.loadLabel(pm));
            it.icon = ai.loadIcon(pm);
            it.launchable = pm.getLaunchIntentForPackage(pi.packageName) != null;
            out.add(it);
        }
        out.sort((a, b) -> a.label.compareToIgnoreCase(b.label));
        return out;
    }

    private void applyFilter() {
        String q = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        boolean everything = showAll.isChecked();
        shown.clear();
        // Selected apps first, then the rest.
        for (int pass = 0; pass < 2; pass++) {
            for (AppItem it : all) {
                boolean sel = selected.contains(it.pkg);
                if ((pass == 0) != sel) continue;
                if (!everything && !it.launchable && !sel) continue;
                if (!q.isEmpty() && !it.label.toLowerCase(Locale.ROOT).contains(q)
                        && !it.pkg.toLowerCase(Locale.ROOT).contains(q)) continue;
                shown.add(it);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void updateTitle() {
        setTitle("Apps through proxy (" + selected.size() + ")");
    }

    private final class AppAdapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int i) { return shown.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int i, View v, ViewGroup parent) {
            if (v == null) {
                v = LayoutInflater.from(AppPickerActivity.this).inflate(R.layout.item_app, parent, false);
            }
            AppItem it = shown.get(i);
            ((ImageView) v.findViewById(R.id.icon)).setImageDrawable(it.icon);
            ((TextView) v.findViewById(R.id.label)).setText(it.label);
            ((TextView) v.findViewById(R.id.pkg)).setText(it.pkg);
            ((CheckBox) v.findViewById(R.id.check)).setChecked(selected.contains(it.pkg));
            return v;
        }
    }
}
