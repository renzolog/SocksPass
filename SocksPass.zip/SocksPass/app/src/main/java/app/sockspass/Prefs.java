package app.sockspass;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

final class Prefs {
    private final SharedPreferences sp;

    Prefs(Context ctx) {
        sp = ctx.getSharedPreferences("config", Context.MODE_PRIVATE);
    }

    String host() { return sp.getString("host", ""); }
    int port() { return sp.getInt("port", 1080); }
    boolean auth() { return sp.getBoolean("auth", false); }
    String user() { return sp.getString("user", ""); }
    String pass() { return sp.getString("pass", ""); }
    boolean remoteDns() { return sp.getBoolean("remoteDns", true); }

    Set<String> apps() {
        return new HashSet<>(sp.getStringSet("apps", new HashSet<>()));
    }

    void saveServer(String host, int port, boolean auth, String user, String pass, boolean remoteDns) {
        sp.edit()
                .putString("host", host)
                .putInt("port", port)
                .putBoolean("auth", auth)
                .putString("user", user)
                .putString("pass", pass)
                .putBoolean("remoteDns", remoteDns)
                .apply();
    }

    void saveApps(Set<String> apps) {
        sp.edit().putStringSet("apps", new HashSet<>(apps)).apply();
    }
}
