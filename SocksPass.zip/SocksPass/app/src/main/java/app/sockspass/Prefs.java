package app.sockspass;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

final class Prefs {
    private final SharedPreferences sp;

    Prefs(Context ctx) {
        sp = ctx.getSharedPreferences("config", Context.MODE_PRIVATE);
    }

    String host() { return sp.getString("host", ""); }
    int port() { return sp.getInt("port", 1080); }
    boolean auth() { return sp.getBoolean("auth", false); }
    String user() { return sp.getString("user", ""); }
    String pass() { return sp.getString("pass", ""); }
    boolean remoteDns() { return sp.getBoolean("remoteDns", true); }

    // "socks" = direct SOCKS5 server, "ssh" = SSH tunnel (like ssh -D)
    boolean sshMode() { return "ssh".equals(sp.getString("mode", "socks")); }
    String sshHost() { return sp.getString("sshHost", ""); }
    int sshPort() { return sp.getInt("sshPort", 22); }
    String sshUser() { return sp.getString("sshUser", ""); }
    String sshKey() { return sp.getString("sshKey", ""); }
    String sshPassphrase() { return sp.getString("sshPassphrase", ""); }
    /** Base64 host key pinned on first successful connection. */
    String sshHostKey() { return sp.getString("sshHostKey", ""); }
    String sshHostFingerprint() { return sp.getString("sshHostFp", ""); }

    void setMode(boolean ssh) { sp.edit().putString("mode", ssh ? "ssh" : "socks").apply(); }

    void saveSsh(String host, int port, String user, String passphrase) {
        sp.edit()
                .putString("sshHost", host)
                .putInt("sshPort", port)
                .putString("sshUser", user)
                .putString("sshPassphrase", passphrase)
                .apply();
    }

    void setSshKey(String key) { sp.edit().putString("sshKey", key).apply(); }

    void pinHostKey(String key, String fingerprint) {
        sp.edit().putString("sshHostKey", key).putString("sshHostFp", fingerprint).apply();
    }

    void forgetHostKey() { sp.edit().remove("sshHostKey").remove("sshHostFp").apply(); }

    /** "host:port" of whatever the app connects to in the current mode. */
    String endpoint() {
        return sshMode() ? sshUser() + "@" + sshHost() + ":" + sshPort() : host() + ":" + port();
    }

    Set<String> apps() {
        return new HashSet<>(sp.getStringSet("apps", new HashSet<>()));
    }

    void saveServer(String host, int port, boolean auth, String user, String pass, boolean remoteDns) {
        sp.edit()
                .putString("host", host)
                .putInt("port", port)
                .putBoolean("auth", auth)
                .putString("user", user)
                .putString("pass", pass)
                .putBoolean("remoteDns", remoteDns)
                .apply();
    }

    void saveApps(Set<String> apps) {
        sp.edit().putStringSet("apps", new HashSet<>(apps)).apply();
    }
}
