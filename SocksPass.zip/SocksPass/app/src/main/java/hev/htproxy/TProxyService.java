package hev.htproxy;

/** JNI bridge to hev-socks5-tunnel. Package and class name must match the native library. */
public final class TProxyService {
    private TProxyService() {
    }

    static {
        System.loadLibrary("hev-socks5-tunnel");
    }

    public static native boolean TProxyStartService(String configPath, int fd);

    public static native boolean TProxyStopService();

    public static native boolean TProxyIsRunning();

    /** Returns [txPackets, txBytes, rxPackets, rxBytes]. */
    public static native long[] TProxyGetStats();
}
