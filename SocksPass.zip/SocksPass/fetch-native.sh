#!/usr/bin/env bash
# Downloads the native tun2socks engine (hev-socks5-tunnel) into the jni folder.
set -euo pipefail
HEV_VERSION="2.19.0"
DEST="$(dirname "$0")/app/src/main/jni/hev-socks5-tunnel"
rm -rf "$DEST"
git clone --branch "$HEV_VERSION" --depth 1 --recurse-submodules --shallow-submodules \
  https://github.com/heiher/hev-socks5-tunnel.git "$DEST"
