# SocksPass

Minimal Android app that sends the traffic of **apps you choose** through a **SOCKS5** proxy.
It uses Android's VpnService (no root) with [hev-socks5-tunnel](https://github.com/heiher/hev-socks5-tunnel) 2.19.0 as the tun2socks engine.

- Per-app routing: only selected apps go through the proxy; everything else is untouched.
- SOCKS5 with or without username/password.
- "Resolve DNS on the proxy": hostnames are resolved by the proxy (no DNS leaks, and no UDP support needed on the server).
- TCP always works; UDP (e.g. QUIC, games) needs a server that supports SOCKS5 UDP ASSOCIATE.
- Android 10+ (minSdk 29), arm64-v8a and armeabi-v7a.

## Build with GitHub Actions

1. Create a repo (private is fine) and push this folder to `main`.
2. Actions → **Build APK** runs automatically. Download the `SocksPass-apk` artifact (a zip containing the APK).
3. Pushing a tag like `v1.0` also attaches the APK to a GitHub Release, which is easier to download on the phone.

### Signing (recommended)

Without secrets, each build is signed with a fresh debug key. It installs fine, but you must uninstall before installing a newer build.
For in-place updates, create a keystore once and add four repo secrets:

```bash
keytool -genkeypair -v -keystore release.jks -alias sockspass -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.jks   # macOS: base64 -i release.jks
```

| Secret | Value |
|---|---|
| `SIGNING_KEYSTORE_BASE64` | output of the base64 command |
| `SIGNING_STORE_PASSWORD` | keystore password |
| `SIGNING_KEY_ALIAS` | `sockspass` |
| `SIGNING_KEY_PASSWORD` | key password (same as store password unless you set another) |

Keep `release.jks` safe and out of git (it is in `.gitignore`).

## Build locally (Android Studio)

Run `./fetch-native.sh` once, then open the folder in Android Studio (NDK is installed automatically or via SDK Manager).

## Use

1. Enter host, port and (optionally) username/password.
2. **Choose apps** → tick the apps to proxy. "Show background/system apps" reveals apps without a launcher icon.
3. **Start** → accept Android's VPN prompt the first time. A key icon appears in the status bar.

To check it works: select your browser, start, and open an IP-check site. It should show the proxy's IP.

Note: Android allows one VPN at a time, so this cannot run together with another VPN app.
